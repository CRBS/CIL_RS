<?php 
    require_once 'CILUtil.php';
    $cutil = new CILUtil();
    $ccdb = $ccdb_data['CCDB'];
    //echo "----------------------Testing-------------------";
    //var_dump($ccdb);
?>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <div class="row">
                 <br/>
                <div class="col-md-12">
                     <?php 
                     
                        echo "-----------Inner image";
                            //include_once 'inner_pages/innerImage.php' 
                     ?>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                
                     <?php 
                            //include_once 'inner_pages/innerTermsAndConditions.php' 
                     ?>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                
                     <?php 
                        //include_once 'inner_pages/innerSocialMedia.php' 
                     ?>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                
                     <?php 
                            //include_once 'inner_pages/innerComments.php' 
                     ?>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="row">
                 
                <div class="col-md-12">
                    <br/>
                    <button class="btn-u btn-u-xs rounded-4x btn-u-green" type="button">Add to photobox</button>
                     <?php 
                            //include_once 'inner_pages/innerDescription.php' 
                     ?>
                </div>
                
                <div class="col-md-12">
                     <?php 
                            //include_once 'inner_pages/innerTechnical.php' 
                     ?>
                </div>
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="row">
                                <div class="col-md-12">
                                    <?php 
                                        //include_once 'inner_pages/innerBiologicalSources.php' 
                                    ?>
                                    
                                </div>
                                <div class="col-md-12">
                                        <?php 
                                            //include_once 'inner_pages/innerBiologicalContext.php' 
                                        ?>

                                </div>
                                <div class="col-md-12">
                                        <?php 
                                            //include_once 'inner_pages/innerAttribution.php' 
                                        ?>

                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="row">
                                <div class="col-md-12">
                                        <?php 
                                            //include_once 'inner_pages/innerImaging.php' 
                                        ?>

                                </div>
                                <div class="col-md-12">
                                        <?php 
                                            //include_once 'inner_pages/innerSamplePreparation.php' 
                                        ?>

                                </div>
                                <div class="col-md-12">
                                        <?php 
                                            //include_once 'inner_pages/innerDimension.php' 
                                        ?>

                                </div>
                            </div>
                        </div>
                        
                        
                    </div>
                    
                </div>
            </div>
    
    
        </div>
        
    </div>
</div>
