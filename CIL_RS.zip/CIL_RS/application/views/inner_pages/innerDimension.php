<!-------Biological sources--------->
<?php
    if(isset($core['DIMENSION']) )
    {
        echo "<h2>Dimension</h2>";
        echo $cutil->outputDimension($core,"DIMENSION", "DIMENSION");
        
       
    }
?>
<!-------End Biological sources--------->
