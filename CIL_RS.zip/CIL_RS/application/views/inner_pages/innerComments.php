<div class="row">
    <div class="col-md-12">

        <div class='pnyxediv'>
        <span class='pnyxe_comment_label'>Comments:</span>
        <span style="display:none;">Powered by Pnyxe</span>
        <script type="text/javascript" language="javascript" id="pnyxeDiscussItJs" src="http://www.pnyxe.com/PnyxeDiscussItJs.jsp"></script>
        <script type="text/javascript" language="javascript" id="pnyxeDiscussItInitJs970937">try { var pnyxeWebWidget_clientKey = "YtnXZJTAXu6nne5CQpKzIA"; var pnyxeDiscussIt = new PnyxeDiscussIt(); pnyxeDiscussIt.init("970937"); } catch (e) {}</script>
        <noscript><a href="http://www.pnyxe.com/webWidgets?source=wwcCodeSpanPromotion2">Comment Box Free</a></noscript>

        </div>

    </div>
    <div class="col-md-12">
    *CIL – Cell Image Library accession number. Please use this to reference an image.
    </div>
</div>