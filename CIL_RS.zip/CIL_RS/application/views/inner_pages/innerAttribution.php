<!-------Biological sources--------->
<?php
    if(isset($core['ATTRIBUTION']) )
    {
        echo "<h2>Attribution</h2>";
        echo $cutil->outputDataSection($core,"ATTRIBUTION", "Names");
        
       
    }
?>
<!-------End Biological sources--------->
