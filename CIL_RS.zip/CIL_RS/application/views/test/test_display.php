<?php

echo phpinfo();


